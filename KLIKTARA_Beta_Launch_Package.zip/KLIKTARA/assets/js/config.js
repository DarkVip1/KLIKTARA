// Masukkan Project URL dan anon/public key Supabase. Jangan pernah gunakan service_role key di frontend.
window.KLIKTARA_CONFIG={SUPABASE_URL:"https://YOUR-PROJECT.supabase.co",SUPABASE_ANON_KEY:"YOUR_SUPABASE_ANON_KEY"};
window.sb=null;
if(window.supabase&&!window.KLIKTARA_CONFIG.SUPABASE_URL.includes("YOUR-PROJECT"))window.sb=window.supabase.createClient(window.KLIKTARA_CONFIG.SUPABASE_URL,window.KLIKTARA_CONFIG.SUPABASE_ANON_KEY);
window.requireBackend=()=>{if(!window.sb)throw new Error("Supabase belum dikonfigurasi. Ikuti README.md.");return window.sb;};
window.setTheme=t=>{document.body.classList.toggle("light",t==="light");localStorage.setItem("kliktara-theme",t);};
document.addEventListener("DOMContentLoaded",()=>{if(localStorage.getItem("kliktara-theme")==="light")document.body.classList.add("light");const b=document.getElementById("themeToggle");if(b)b.onclick=()=>window.setTheme(document.body.classList.contains("light")?"dark":"light");});