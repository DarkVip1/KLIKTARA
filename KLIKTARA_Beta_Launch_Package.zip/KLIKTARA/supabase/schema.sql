create extension if not exists pgcrypto;
create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade,display_name text not null default '',username text unique,role text not null default 'member' check(role in('member','admin')),created_at timestamptz not null default now());
create table if not exists public.ads(id uuid primary key default gen_random_uuid(),brand text not null,title text not null,category text not null default 'Lainnya',description text not null default '',image_url text,target_url text,status text not null default 'draft' check(status in('draft','published','archived')),created_by uuid references auth.users(id),created_at timestamptz not null default now());
create table if not exists public.ad_submissions(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,brand text not null,title text not null,category text not null default 'Lainnya',description text not null,target_url text,status text not null default 'pending' check(status in('pending','approved','rejected')),created_at timestamptz not null default now(),reviewed_at timestamptz);
create index if not exists ads_status_created_idx on public.ads(status,created_at desc);
create index if not exists submissions_user_idx on public.ad_submissions(user_id,created_at desc);
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,display_name,username) values(new.id,coalesce(new.raw_user_meta_data->>'display_name',''),nullif(new.raw_user_meta_data->>'username','')); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;
alter table public.profiles enable row level security; alter table public.ads enable row level security; alter table public.ad_submissions enable row level security;
create policy "profile self or admin read" on public.profiles for select using(id=auth.uid() or public.is_admin());
create policy "profile self update" on public.profiles for update using(id=auth.uid()) with check(id=auth.uid() and role='member');
create policy "published ads read" on public.ads for select using(status='published' or public.is_admin());
create policy "admin manage ads" on public.ads for all using(public.is_admin()) with check(public.is_admin());
create policy "member own submission insert" on public.ad_submissions for insert with check(user_id=auth.uid() and status='pending');
create policy "member own or admin submission read" on public.ad_submissions for select using(user_id=auth.uid() or public.is_admin());
create policy "admin review submissions" on public.ad_submissions for update using(public.is_admin()) with check(public.is_admin());
-- Buat akun owner lewat Register, verifikasi, salin UUID di Authentication > Users,
-- lalu jalankan: update public.profiles set role='admin' where id='UUID-AKUN-OWNER';
-- Jangan berikan hak admin dari form publik. Jika SQL dijalankan ulang, hapus policy lama lebih dulu atau gunakan nama policy yang sama setelah DROP.
