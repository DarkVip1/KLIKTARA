# KLIKTARA — paket Beta Launch

## Penting
Ini adalah fondasi website yang dapat dipasang di hosting. Fitur login, database, pengajuan, dan Admin Studio baru aktif setelah Supabase dikonfigurasi. Paket ini belum mencakup upload file langsung, push-subscription/pengiriman push, analytics lanjutan, audit log, atau editor halaman visual. Jangan mengiklankannya sebagai sistem produksi yang sudah diaudit.

## A. Siapkan Supabase
1. Buat project di Supabase.
2. Buka Project Settings → API.
3. Salin Project URL dan anon/public key.
4. Edit `assets/js/config.js`, isi kedua nilai tersebut. Jangan gunakan `service_role` key.
5. Buka SQL Editor dan jalankan isi `supabase/schema.sql`.
6. Authentication → Providers: aktifkan Email.
7. Authentication → URL Configuration: set Site URL dan Redirect URL ke domain situs kamu, misalnya `https://domainmu.example/login.html`.

## B. Buat akun admin pertama
1. Buka halaman `/register.html` di situs yang sudah terpasang.
2. Daftar menggunakan email pemilik yang memang kamu kuasai; selesaikan verifikasi email.
3. Supabase → Authentication → Users → salin UUID akun tersebut.
4. SQL Editor jalankan `update public.profiles set role='admin' where id='UUID-AKUN-OWNER';` dengan UUID sebenarnya.
5. Login memakai akun itu, lalu buka `/admin/`.
6. Tes dengan akun member biasa: akun itu harus ditolak saat membuka Admin Studio.

## C. Pasang di hosting dari Android
1. Ekstrak ZIP ini di HP.
2. Buat akun hosting static seperti Netlify atau Cloudflare Pages.
3. Upload/deploy isi folder `KLIKTARA` (yang berisi `index.html`, bukan folder induk ZIP).
4. Tunggu domain HTTPS aktif.
5. Masukkan domain tersebut ke Supabase Authentication → URL Configuration.
6. Tes daftar, verifikasi email, login, edit profil, kirim pengajuan, moderasi admin, dan tampilan publik.
7. Jika memakai path subfolder, sesuaikan URL `service-worker.js` dan `start_url` di manifest.

## D. Checklist sebelum dibuka untuk publik
- Uji seluruh alur dengan akun admin dan member terpisah.
- Tambahkan halaman Kebijakan Privasi, Ketentuan Layanan, kontak resmi, serta prosedur penghapusan akun/data.
- Publikasikan hanya kontak bisnis yang disetujui wali/penanggung jawab.
- Siapkan moderasi, pelaporan penyalahgunaan, backup, dan pemantauan biaya.
- Audit RLS dan konfigurasi keamanan sebelum menerima data anggota sungguhan.

## Yang sudah ada
Website publik, katalog iklan dari database, pencarian/filter, tema gelap/terang, auth Supabase, profil member, submit iklan, status pengajuan, Admin Studio dengan pemeriksaan role, manajemen iklan dasar, review submission, daftar member terbatas.

## Yang belum ada
Upload foto dari galeri (form admin sementara menerima URL gambar HTTPS), sistem push notification lengkap (service worker hanya menerima push; perlu VAPID + subscription + backend sender), email notifikasi, analytics mendalam, audit log, page builder visual, halaman legal final.
